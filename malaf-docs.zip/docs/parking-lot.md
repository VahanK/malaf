# Parking Lot — ideas wait here, evaluated at monthly triage or gate resolutions only

**Rule:** one line per idea. Nothing here gets built until ≥5 paying users ask, a gate resolves, or monthly triage promotes it. (CLAUDE.md red lines still apply.)

- **Meetups + lanyards** (vahan, Jul 19): Malaf freelancer meetups where attendees get a physical lanyard/badge with their QR card — wearable malaf for expos, wedding fairs, campus events. Fits the identity-object thesis + community layer. Slot: September+, after campus playbook ignites; pairs with the founder printed cards. Cost ~$2–4/lanyard.
- **Custom domains** (Jul 19): paid add-on, v1.1 — cheap on Vercel, DNS support burden, low segment demand. Trigger: ≥5 paying requests.
- **PDF upload for case cards** (writers segment): v1.1 — excerpt cards ship in v1.
- **Deposit requests ("50% to book")**: v1.1 candidate — likely early cluster, watch for it in founder conversations.
- **Gulf/diaspora expansion**: opens at Lebanon farm slowdown or $1k MRR — kit already written (docs/validation-kit-gulf-shelf.md).
- **Phase 2 directory/marketplace (Khedme resurrection)**: locked behind $2k MRR or month 12.
